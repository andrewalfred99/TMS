﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TMS.Services
{
    public class AuthMessageSenderOptions
    {
        public string SendGridUser { get { return "azure_1282e33bcc68879770ae2cfb6925520c3@azure.com"; } }

        public string SendGridKey { get { return "SG.-K_xNvTaRtCbxoEeCGmuAQ.WBNvuo9QQp9RlPFMznBNyobcQmwf2oOp1AwgmDWKmDQ1"; } } //DKN
    }
}
