﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TMS.Data
{
    public class FacultyVM
    {
        public String Name { get; set; }
    }
}
